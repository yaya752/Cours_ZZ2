package com.modernarchi.tp2.controller;

public class AddPixelBody {

    public int x;
    public int y;
    public String color;

}
