package com.modernarchi.tp2.model;

public class PixelBoard {

    public PixelBoard() {
    }

    public static final int SIZE = 2000;

    public Pixel[][] store = new Pixel[SIZE][SIZE];


}
