package com.modernarchi.tp2.model;

import java.awt.*;

public class Pixel {

    public String color;

    public Pixel(String color) {
        this.color = color;
    }

}
